import { BrowserModule } from '@angular/platform-browser';
import { NgModule} from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { AvatarComponent } from './avatar/avatar.component';
import { ProfileSummaryComponent } from './profile-summary/profile-summary.component';
import { TopleftComponent } from './topleft/topleft.component';
import { ToprightComponent } from './topright/topright.component';
import { RatingskillsComponent } from './ratingskills/ratingskills.component';
import { EduDetailsComponent } from './edu-details/edu-details.component';
import { PerDetailsComponent } from './per-details/per-details.component';
import { DegreeconverterComponent } from './degreeconverter/degreeconverter.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    AvatarComponent,
    ProfileSummaryComponent,
    TopleftComponent,
    ToprightComponent,
    RatingskillsComponent,
    EduDetailsComponent,
    PerDetailsComponent,
    DegreeconverterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
