import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DegreeconverterComponent } from './degreeconverter.component';

describe('DegreeconverterComponent', () => {
  let component: DegreeconverterComponent;
  let fixture: ComponentFixture<DegreeconverterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DegreeconverterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DegreeconverterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
