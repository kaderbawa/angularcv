import { Component, OnInit, NgModule} from '@angular/core';

@Component({
  selector: 'app-degreeconverter',
  templateUrl: './degreeconverter.component.html',
  styleUrls: ['./degreeconverter.component.css']
})
export class DegreeconverterComponent implements OnInit {
  
 
  constructor() { }

  ngOnInit() {
  }
  celsius: number = 0; 
}
