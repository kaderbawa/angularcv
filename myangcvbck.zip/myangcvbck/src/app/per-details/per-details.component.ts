import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-per-details',
  templateUrl: './per-details.component.html',
  styleUrls: ['./per-details.component.css']
})
export class PerDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
