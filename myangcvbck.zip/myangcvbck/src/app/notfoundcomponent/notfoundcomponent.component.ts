import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notfoundcomponent',
  templateUrl: './notfoundcomponent.component.html',
  styleUrls: ['./notfoundcomponent.component.css']
})
export class NotfoundcomponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
