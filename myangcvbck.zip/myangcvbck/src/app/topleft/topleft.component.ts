import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-topleft',
  templateUrl: './topleft.component.html',
  styleUrls: ['./topleft.component.css']
})
export class TopleftComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
