import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-topright',
  templateUrl: './topright.component.html',
  styleUrls: ['./topright.component.css']
})
export class ToprightComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
