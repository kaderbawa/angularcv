import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RatingskillsComponent } from './ratingskills.component';

describe('RatingskillsComponent', () => {
  let component: RatingskillsComponent;
  let fixture: ComponentFixture<RatingskillsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RatingskillsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RatingskillsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
