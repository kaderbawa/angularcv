import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ratingskills',
  templateUrl: './ratingskills.component.html',
  styleUrls: ['./ratingskills.component.css']
})
export class RatingskillsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
